 $(function(){
  $(document).ready(function($){
    
    //Hover just use class="rollover" and create two images _on _off
    //$("img.rollover").hover(
    //  function() { this.src = this.src.replace("_off", "_on");
    //},
    //  function() { this.src = this.src.replace("_on", "_off");
    //});
           
    // Intialize PrettyPhoto
    $("a[rel^='prettyPhoto']").prettyPhoto({overlay_gallery:true, allow_resize:false, show_title:false, deeplinking:false, social_tools:false});
    $("area[rel^='prettyPhoto']").prettyPhoto();
    
    // Google Analytics External event 
    $("a[href*='store.grouppublishing.com/OA_HTML']").mouseup(function(){
      _gaq.push(['_link', 'External', 'click', $(this).attr('href')]);
    });
    
  }); 
}); 


// Get querystring keys
function qs(key) {
    key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta chars
    var match = location.search.match(new RegExp("[?&]"+key+"=([^&]+)(&|$)"));
    return match && decodeURIComponent(match[1]);
}